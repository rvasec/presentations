# RVASec AI 101 Demos

These demos are designed to be opened directly in a browser during the talk. They use only local HTML, CSS, and JavaScript.

## Live Browser Demos

- `index.html` - launcher
- `tokenization_demo.html`
- `marble_precision_recall_demo.html`
- `preprocessing_demo.html`
- `diffusion_demo.html`
- `reward_hacking_demo.html`

Each page supports replay with the page controls and the spacebar.

## Manim Source And Fallback Videos

`manim_scenes/ai_101_demos.py` contains Manim Community Edition scene source for rendering video versions later.

Rendered fallback videos are in `media/videos/ai_101_demos/480p15/` from the project root:

- `TokenizationScene.mp4`
- `MarblePrecisionRecallScene.mp4`
- `PreprocessingScene.mp4`
- `DiffusionScene.mp4`
- `RewardHackingScene.mp4`

To rerender, install Manim Community Edition and run these commands from the project root:

```powershell
python -m manim -ql --media_dir media demos\manim_scenes\ai_101_demos.py TokenizationScene
python -m manim -ql --media_dir media demos\manim_scenes\ai_101_demos.py MarblePrecisionRecallScene
python -m manim -ql --media_dir media demos\manim_scenes\ai_101_demos.py PreprocessingScene
python -m manim -ql --media_dir media demos\manim_scenes\ai_101_demos.py DiffusionScene
python -m manim -ql --media_dir media demos\manim_scenes\ai_101_demos.py RewardHackingScene
```

## Fallback Plan

The PowerPoint deck includes static fallback slides for the live demos. If a browser demo fails on stage, use the corresponding deck slide and keep moving.
