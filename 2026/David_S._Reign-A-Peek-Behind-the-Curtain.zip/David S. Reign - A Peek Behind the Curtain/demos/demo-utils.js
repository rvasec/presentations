const Demo = (() => {
  const colors = {
    bg: "#07090f",
    panel: "#101720",
    panel2: "#151d29",
    ink: "#f4f7fb",
    muted: "#9aa8b5",
    blue: "#58a6ff",
    green: "#78d55a",
    gold: "#f3c969",
    red: "#ff6673",
    purple: "#b88cff",
    orange: "#ffad66",
    line: "rgba(255,255,255,.16)"
  };

  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const ease = (t) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

  function setupCanvas(canvas) {
    const ctx = canvas.getContext("2d");
    function resize() {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    window.addEventListener("resize", resize);
    resize();
    return ctx;
  }

  function clear(ctx, w, h) {
    ctx.fillStyle = colors.bg;
    ctx.fillRect(0, 0, w, h);
    drawGrid(ctx, w, h);
  }

  function drawGrid(ctx, w, h) {
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,.035)";
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 48) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 48) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function roundRect(ctx, x, y, w, h, r = 8, fill = colors.panel, stroke = colors.line) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    if (fill) {
      ctx.fillStyle = fill;
      ctx.fill();
    }
    if (stroke) {
      ctx.strokeStyle = stroke;
      ctx.stroke();
    }
    ctx.restore();
  }

  function text(ctx, value, x, y, opts = {}) {
    const {
      size = 18,
      color = colors.ink,
      weight = 500,
      align = "left",
      baseline = "alphabetic",
      maxWidth
    } = opts;
    ctx.save();
    ctx.fillStyle = color;
    ctx.font = `${weight} ${size}px Segoe UI, Arial, sans-serif`;
    ctx.textAlign = align;
    ctx.textBaseline = baseline;
    if (maxWidth) ctx.fillText(value, x, y, maxWidth);
    else ctx.fillText(value, x, y);
    ctx.restore();
  }

  function wrapText(ctx, value, x, y, maxWidth, lineHeight, opts = {}) {
    const words = String(value).split(/\s+/);
    let line = "";
    let yy = y;
    ctx.save();
    ctx.font = `${opts.weight || 500} ${opts.size || 16}px Segoe UI, Arial, sans-serif`;
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && line) {
        text(ctx, line, x, yy, opts);
        line = word;
        yy += lineHeight;
      } else {
        line = test;
      }
    }
    if (line) text(ctx, line, x, yy, opts);
    ctx.restore();
    return yy + lineHeight;
  }

  function arrow(ctx, x1, y1, x2, y2, color = colors.green, width = 3) {
    const angle = Math.atan2(y2 - y1, x2 - x1);
    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - 12 * Math.cos(angle - Math.PI / 6), y2 - 12 * Math.sin(angle - Math.PI / 6));
    ctx.lineTo(x2 - 12 * Math.cos(angle + Math.PI / 6), y2 - 12 * Math.sin(angle + Math.PI / 6));
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function pill(ctx, x, y, w, h, label, fill, stroke = "rgba(255,255,255,.2)", labelColor = colors.ink) {
    roundRect(ctx, x, y, w, h, 8, fill, stroke);
    text(ctx, label, x + w / 2, y + h / 2, {
      size: Math.min(18, Math.max(11, h * 0.45)),
      color: labelColor,
      weight: 700,
      align: "center",
      baseline: "middle",
      maxWidth: w - 10
    });
  }

  function deterministicRandom(seed) {
    let s = seed >>> 0;
    return () => {
      s = (1664525 * s + 1013904223) >>> 0;
      return s / 4294967296;
    };
  }

  function connectButtons(selector, onClick) {
    document.querySelectorAll(selector).forEach((button) => {
      button.addEventListener("click", () => {
        document.querySelectorAll(selector).forEach((b) => b.classList.remove("active"));
        button.classList.add("active");
        onClick(button.dataset.value || button.textContent.trim(), button);
      });
    });
  }

  return {
    colors,
    clamp,
    lerp,
    ease,
    setupCanvas,
    clear,
    roundRect,
    text,
    wrapText,
    arrow,
    pill,
    deterministicRandom,
    connectButtons
  };
})();
