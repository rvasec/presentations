from __future__ import annotations

import math
import random
import colorsys
import textwrap
from functools import lru_cache

from manim import *


BG = "#07090F"
PANEL = "#101720"
INK = "#F4F7FB"
MUTED = "#9AA8B5"
BLUE = "#58A6FF"
GREEN = "#78D55A"
GOLD = "#F3C969"
RED = "#FF6673"
PURPLE = "#B88CFF"
ORANGE = "#FFAD66"

config.background_color = BG


def label(text: str, size: int = 30, color: str = INK, weight=BOLD) -> Text:
    return Text(text, font="Segoe UI", font_size=size, color=color, weight=weight)


def wrapped_label(
    text: str,
    size: int = 22,
    color: str = MUTED,
    weight=NORMAL,
    width: int = 34,
    buff: float = 0.12,
) -> VGroup:
    lines = textwrap.wrap(text, width=width)
    group = VGroup(*[label(line, size, color, weight) for line in lines])
    group.arrange(DOWN, aligned_edge=LEFT, buff=buff)
    return group


def token_box(text: str, color: str, width: float | None = None) -> VGroup:
    t = label(text, 24, INK, BOLD)
    w = width if width else max(0.9, t.width + 0.35)
    box = RoundedRectangle(width=w, height=0.55, corner_radius=0.08)
    box.set_fill(color, opacity=0.22)
    box.set_stroke(color, width=2)
    t.move_to(box)
    return VGroup(box, t)


def metric_card(title: str, value: str, color: str) -> VGroup:
    box = RoundedRectangle(width=3.5, height=1.15, corner_radius=0.08)
    box.set_fill(PANEL, opacity=1)
    box.set_stroke("#FFFFFF", opacity=0.16)
    top = label(title, 20, MUTED, BOLD).move_to(box.get_top() + DOWN * 0.32)
    val = label(value, 30, color, BOLD).move_to(box.get_bottom() + UP * 0.36)
    return VGroup(box, top, val)


def hsl_hex(hue: float, sat: float, light: float) -> str:
    r, g, b = colorsys.hls_to_rgb((hue % 360) / 360, light / 100, sat / 100)
    return f"#{int(r * 255):02X}{int(g * 255):02X}{int(b * 255):02X}"


def lock_intensity(x: float, y: float) -> float:
    cx = x - 0.5
    cy = y - 0.54
    lock_body = 0.31 < x < 0.69 and 0.48 < y < 0.78
    shackle = abs(math.sqrt(cx * cx + (cy + 0.03) * (cy + 0.03)) - 0.25) < 0.04 and y < 0.54 and y > 0.23
    hole = math.sqrt((x - 0.5) ** 2 + (y - 0.62) ** 2) < 0.045 or (0.485 < x < 0.515 and 0.62 < y < 0.72)
    if hole:
        return 0.08
    if lock_body:
        return 0.92
    if shackle:
        return 0.82
    glow = math.exp(-(cx * cx + cy * cy) * 9) * 0.28
    return glow


def smiley_intensity(x: float, y: float) -> float:
    cx = x - 0.5
    cy = y - 0.5
    radius = math.hypot(cx, cy)
    face = abs(radius - 0.31) < 0.035
    left_eye = ((x - 0.39) ** 2) / (0.034 ** 2) + ((y - 0.42) ** 2) / (0.052 ** 2) < 1
    right_eye = ((x - 0.61) ** 2) / (0.034 ** 2) + ((y - 0.42) ** 2) / (0.052 ** 2) < 1
    mouth_circle = abs(math.hypot(x - 0.5, y - 0.5) - 0.24) < 0.028
    mouth = mouth_circle and y > 0.54 and 0.31 < x < 0.69
    if left_eye or right_eye:
        return 0.95
    if mouth:
        return 0.9
    if face:
        return 0.84
    glow = math.exp(-(cx * cx + cy * cy) * 8) * 0.24
    return glow


def target_intensity(x: float, y: float) -> float:
    return smiley_intensity(x, y)


def blurred_lock_intensity(x: float, y: float) -> float:
    cx = x - 0.5
    cy = y - 0.56
    soft_center = math.exp(-(cx * cx + cy * cy) * 8.5) * 0.68
    return max(soft_center, lock_intensity(x, y) * 0.32)


def diffusion_color(noise_value: float, target_value: float, progress: float) -> str:
    value = noise_value + (target_value - noise_value) * progress
    hue = 215 + (128 - 215) * progress
    sat = 80 + (62 - 80) * progress
    light = value * 86 + ((14 + value * 62) - value * 86) * progress
    return hsl_hex(hue, sat, light)


def deterministic_random(seed: int):
    state = seed & 0xFFFFFFFF

    def next_value() -> float:
        nonlocal state
        state = (1664525 * state + 1013904223) & 0xFFFFFFFF
        return state / 4294967296

    return next_value


@lru_cache(maxsize=None)
def target_pixels(n: int = 32) -> list[dict[str, float | str]]:
    pts: list[dict[str, float | str]] = []
    for j in range(n):
        for i in range(n):
            x = (i + 0.5) / n
            y = (j + 0.5) / n
            intensity = target_intensity(x, y)
            if intensity > 0.74 and ((i + j) % 2 == 0 or intensity > 0.9):
                pts.append({
                    "x": x,
                    "y": y,
                    "intensity": intensity,
                    "color": GREEN,
                })
    return pts


def learned_vector(
    x: float,
    y: float,
    progress: float,
    target: dict[str, float | str] | None = None,
    n: int = 32,
    use_random: bool = True,
) -> tuple[float, float]:
    sharpness = (2.6 + (145 - 2.6) * progress * progress) if use_random else (1.8 + (42 - 1.8) * progress * progress)
    total = 0.0
    weighted_x = 0.0
    weighted_y = 0.0
    for point in target_pixels(n):
        px = float(point["x"])
        py = float(point["y"])
        dx = px - x
        dy = py - y
        weight = math.exp(-(dx * dx + dy * dy) * sharpness) + 0.0004
        weighted_x += px * weight
        weighted_y += py * weight
        total += weight
    tx = weighted_x / total
    ty = weighted_y / total
    if target:
        target_blend = (progress ** 2.15) if use_random else (progress ** 5.5) * 0.36
        tx = tx + (float(target["x"]) - tx) * target_blend
        ty = ty + (float(target["y"]) - ty) * target_blend
    dx = tx - x
    dy = ty - y
    pull = math.hypot(dx, dy) or 1
    swirl = (0.23 if use_random else 0.12) * (1 - progress)
    vx = dx / pull - dy * swirl
    vy = dy / pull + dx * swirl
    mag = math.hypot(vx, vy) or 1
    return vx / mag, vy / mag


def diffusion_particles(n: int = 32, use_random: bool = True, step_count: int = 12) -> list[dict[str, object]]:
    rng = deterministic_random(23)
    particles: list[dict[str, object]] = []
    for index, target in enumerate(target_pixels(n)):
        x = 0.08 + rng() * 0.84
        y = 0.08 + rng() * 0.84
        states = [{"x": x, "y": y}]
        vector_states = []
        random_segments = []
        for step in range(step_count):
            progress = step / step_count
            next_progress = (step + 1) / step_count
            angle = rng() * math.pi * 2
            jitter = 0.096 * ((1 - next_progress) ** 1.08) if use_random else 0
            random_x = min(0.965, max(0.035, x + math.cos(angle) * jitter))
            random_y = min(0.965, max(0.035, y + math.sin(angle) * jitter))

            field_target = target if (use_random or next_progress > 0.84) else None
            vx, vy = learned_vector(random_x, random_y, next_progress, field_target, n, use_random)
            field_step = 0.045 + next_progress * 0.034
            field_x = min(0.965, max(0.035, random_x + vx * field_step))
            field_y = min(0.965, max(0.035, random_y + vy * field_step))
            target_pull = (0.014 + (next_progress ** 2.55) * 0.25) if use_random else (0.004 + (next_progress ** 5.6) * 0.04)
            field_x = field_x + (float(target["x"]) - field_x) * target_pull
            field_y = field_y + (float(target["y"]) - field_y) * target_pull

            if use_random and step == step_count - 1:
                field_x = float(target["x"])
                field_y = float(target["y"])
            vector_states.append({"x": field_x, "y": field_y})
            random_segments.append({
                "from_x": x,
                "from_y": y,
                "to_x": random_x,
                "to_y": random_y,
                "distance": math.hypot(random_x - x, random_y - y),
            })
            x = field_x
            y = field_y
            states.append({"x": x, "y": y})
        particles.append({"index": index, "target": target, "states": states, "vector_states": vector_states, "random_segments": random_segments})
    return particles


class TokenizationScene(Scene):
    def construct(self):
        self.camera.background_color = BG
        title = label("Tokenization Lab", 38, INK)
        title.to_edge(UP)
        input_panel = RoundedRectangle(width=11.2, height=1.05, corner_radius=0.08)
        input_panel.set_fill(PANEL, opacity=1)
        input_panel.set_stroke("#FFFFFF", opacity=0.16)
        input_panel.next_to(title, DOWN, buff=0.32)
        text_label = label("Text", 18, MUTED, BOLD).move_to(input_panel.get_left() + RIGHT * 0.45 + UP * 0.26)
        sentence = label("A model can unpack cybersecurity into cyber + security.", 25, INK)
        sentence.move_to(input_panel.get_center() + DOWN * 0.14)
        self.play(Write(title), FadeIn(input_panel), FadeIn(text_label), FadeIn(sentence, shift=UP * 0.2))

        candidates_title = label("Next-token candidates", 20, MUTED, BOLD).next_to(input_panel, DOWN, buff=0.18)
        candidates_title.align_to(input_panel, LEFT).shift(RIGHT * 0.12)
        candidates = VGroup(
            token_box("cybersecurity 34%", GREEN, 2.55),
            token_box("context 25%", BLUE, 2.0),
            token_box("tokens 22%", GOLD, 1.85),
            token_box("patterns 19%", PURPLE, 2.05),
        ).arrange(RIGHT, buff=0.16)
        candidates.next_to(candidates_title, DOWN, buff=0.14)
        candidates.align_to(input_panel, LEFT).shift(RIGHT * 0.10)
        sample = token_box("Sample", BLUE, 1.25).next_to(candidates_title, RIGHT, buff=0.35)
        self.play(FadeIn(candidates_title), FadeIn(sample), LaggedStart(*[FadeIn(c) for c in candidates], lag_ratio=0.08))

        modes = [
            (
                "Word tokenization",
                ["A", "model", "can", "unpack", "cybersecurity", "into", "cyber", "+", "security", "."],
                BLUE,
                "Simple, but big words stay glued together.",
            ),
            (
                "Character tokenization",
                ["A", "space", "m", "o", "d", "e", "l", "space", "c", "a", "n", "..."],
                PURPLE,
                "Precise, but the token count explodes quickly.",
            ),
            (
                "Subword tokenization",
                ["A", " model", " can", " unpack", " cyber", "security", " into", " cyber", " +", " security", "."],
                GREEN,
                "The real star: common chunks become reusable building blocks.",
            ),
        ]

        previous = None
        previous_note = None
        for mode_name, pieces, color, note_text in modes:
            mode = label(mode_name, 27, color).move_to(DOWN * 0.35)
            boxes = VGroup(*[token_box(piece, color) for piece in pieces])
            boxes.arrange_in_grid(rows=2 if len(pieces) > 8 else 1, buff=(0.16, 0.28))
            boxes.next_to(mode, DOWN, buff=0.45)
            note = VGroup()
            count = metric_card("token count", str(len(pieces)), GOLD).scale(0.78).to_edge(DOWN).shift(LEFT * 2.1)
            budget = metric_card("context budget", f"{round(len(pieces) / 80 * 100)}%", BLUE).scale(0.78).to_edge(DOWN).shift(RIGHT * 2.1)
            if previous:
                self.play(FadeOut(previous), FadeOut(previous_note))
            self.play(FadeIn(mode, shift=UP * 0.15), LaggedStart(*[FadeIn(b, shift=UP * 0.2) for b in boxes], lag_ratio=0.06))
            self.play(FadeIn(count), FadeIn(budget))
            self.wait(1.2)
            previous = VGroup(mode, boxes, count, budget)
            previous_note = note
        self.wait(0.8)


class MarblePrecisionRecallScene(Scene):
    def construct(self):
        self.camera.background_color = BG
        title = label("Precision and recall: find the green marbles", 38, INK).to_edge(UP)
        self.play(Write(title))

        green_ids = {3, 8, 14, 27, 41, 55, 63, 76, 82, 97}
        red_ids = [i for i in range(100) if i not in green_ids]
        marbles = VGroup()
        for i in range(100):
            dot = Circle(radius=0.13)
            dot.set_fill(GREEN if i in green_ids else RED, opacity=0.95)
            dot.set_stroke("#FFFFFF", opacity=0.12, width=1)
            dot.move_to(LEFT * 4.5 + RIGHT * (i % 10) * 0.34 + DOWN * (i // 10) * 0.34 + UP * 1.2)
            marbles.add(dot)
        self.play(LaggedStart(*[FadeIn(m) for m in marbles], lag_ratio=0.01), run_time=1.3)

        scenarios = [
            ("High precision, low recall", 4, 0, "Clean result, but most greens are missing."),
            ("Low precision, high recall", 9, 40, "Most greens found, but the pile is noisy."),
            ("High precision, high recall", 10, 1, "Nearly complete and nearly clean."),
            ("Low precision, low recall", 2, 9, "Misses most targets and adds wrong ones."),
        ]
        current = VGroup()
        for name, g_count, r_count, note_text in scenarios:
            self.play(FadeOut(current))
            chosen = list(sorted(green_ids))[:g_count] + red_ids[:r_count]
            rings = VGroup()
            for idx in chosen:
                ring = Circle(radius=0.19)
                ring.move_to(marbles[idx])
                ring.set_stroke(GREEN if idx in green_ids else RED, width=4)
                rings.add(ring)
            tp = g_count
            fp = r_count
            precision = 0 if tp + fp == 0 else tp / (tp + fp)
            recall = tp / 10
            panel = RoundedRectangle(width=5.35, height=3.75, corner_radius=0.08)
            panel.set_fill(PANEL, opacity=1)
            panel.set_stroke("#FFFFFF", opacity=0.16)
            panel.to_edge(RIGHT).shift(DOWN * 0.25)
            header = label(name, 25, INK).move_to(panel.get_top() + DOWN * 0.45)
            note = wrapped_label(note_text, 19, MUTED, NORMAL, width=32, buff=0.08)
            note.next_to(header, DOWN, buff=0.28)
            p_text = label(f"precision = {precision:.0%}", 25, GOLD).next_to(note, DOWN, buff=0.42)
            r_text = label(f"recall = {recall:.0%}", 26, GREEN).next_to(p_text, DOWN, buff=0.35)
            counts = label(f"TP {tp}   FP {fp}   FN {10 - tp}", 22, MUTED).next_to(r_text, DOWN, buff=0.42)
            current = VGroup(rings, panel, header, note, p_text, r_text, counts)
            self.play(Create(rings), FadeIn(panel), Write(header), FadeIn(note), FadeIn(p_text), FadeIn(r_text), FadeIn(counts))
            self.wait(1.1)


class PreprocessingScene(Scene):
    def construct(self):
        self.camera.background_color = BG
        title = label("Preprocessing Failure Lab", 38, INK).to_edge(UP)
        self.play(Write(title))

        plot = self._plot_panel("Clustering", ORIGIN)
        self.play(FadeIn(plot))

        clean_pts = [
            (0.16, 0.24, BLUE), (0.23, 0.20, BLUE), (0.29, 0.33, BLUE), (0.36, 0.28, BLUE),
            (0.43, 0.38, BLUE), (0.49, 0.43, BLUE), (0.55, 0.59, GREEN), (0.63, 0.71, GREEN),
            (0.69, 0.65, GREEN), (0.76, 0.78, GREEN), (0.82, 0.70, GREEN), (0.88, 0.81, GREEN),
        ]
        variants = [
            (0.44, 0.27, BLUE), (0.51, 0.31, BLUE), (0.53, 0.37, BLUE),
            (0.47, 0.54, GREEN), (0.52, 0.50, GREEN),
        ]
        duplicates = [
            (0.78, 0.34, GREEN), (0.80, 0.32, GREEN), (0.82, 0.36, GREEN), (0.76, 0.31, GREEN),
            (0.83, 0.33, GREEN), (0.79, 0.35, GREEN), (0.81, 0.30, GREEN),
            (0.55, 0.49, BLUE), (0.57, 0.50, BLUE), (0.59, 0.48, BLUE), (0.56, 0.46, BLUE), (0.60, 0.51, BLUE),
        ]
        wrong_before = [
            (0.43, 0.38, GREEN, BLUE), (0.49, 0.43, GREEN, BLUE),
            (0.55, 0.59, BLUE, GREEN), (0.69, 0.65, BLUE, GREEN),
        ]

        base_dots = VGroup(*[self._point(x, y, color) for x, y, color in clean_pts if (x, y) not in {(0.43, 0.38), (0.49, 0.43), (0.55, 0.59), (0.69, 0.65)}])
        variant_dots = VGroup(*[self._point(x, y, color, "variant") for x, y, color in variants])
        duplicate_dots = VGroup(*[self._point(x, y, color, "duplicate") for x, y, color in duplicates])
        wrong_dots = VGroup(*[self._point(x, y, shown, "wrong") for x, y, shown, _ in wrong_before])
        corrected_dots = VGroup(*[self._point(x, y, truth, "clean") for x, y, _, truth in wrong_before])

        bad_boundary = self._boundary(RED, 1.15, -0.24)
        clean_boundary = self._boundary(GREEN, 0.06, 0.48)

        debt = metric_card("preprocessing debt", "3 open", GOLD).scale(0.54)
        records = metric_card("training records", "29", INK).scale(0.54)
        accuracy = metric_card("validation accuracy", "50%", RED).scale(0.54)
        bad_outcomes = metric_card("bad outcomes", "4", RED).scale(0.54)
        metrics = VGroup(debt, records, accuracy, bad_outcomes).arrange(RIGHT, buff=0.16).next_to(title, DOWN, buff=0.24)
        outcome_note = label("1 false alert / 3 misses", 19, MUTED, NORMAL).next_to(metrics, DOWN, buff=0.18)
        self.play(
            LaggedStart(*[FadeIn(d, scale=0.45) for d in [*base_dots, *variant_dots, *duplicate_dots, *wrong_dots]], lag_ratio=0.025),
            Create(bad_boundary),
            FadeIn(metrics),
            FadeIn(outcome_note),
            run_time=1.6,
        )

        steps = VGroup(
            token_box("1 normalize text", PURPLE, 2.45),
            token_box("2 remove duplicates", GOLD, 2.7),
            token_box("3 correct labels", ORANGE, 2.35),
        ).arrange(RIGHT, buff=0.25).next_to(plot, DOWN, buff=0.28)
        self.play(FadeIn(steps))

        self.play(
            variant_dots.animate.shift(UP * 0.28).set_opacity(0),
            Transform(bad_boundary, self._boundary(RED, 0.75, -0.02)),
            records[2].animate.become(label("24", 30, INK, BOLD).move_to(records[2])),
            run_time=1.0,
        )
        self.play(
            duplicate_dots.animate.shift(UP * 0.28).set_opacity(0),
            Transform(bad_boundary, self._boundary(RED, 0.35, 0.20)),
            records[2].animate.become(label("12", 30, INK, BOLD).move_to(records[2])),
            run_time=1.0,
        )
        self.play(
            ReplacementTransform(wrong_dots, corrected_dots),
            Transform(bad_boundary, clean_boundary),
            bad_boundary.animate.set_color(GREEN),
            debt[2].animate.become(label("clean", 30, GREEN, BOLD).move_to(debt[2])),
            records[2].animate.become(label("12", 30, INK, BOLD).move_to(records[2])),
            accuracy[2].animate.become(label("100%", 30, GREEN, BOLD).move_to(accuracy[2])),
            bad_outcomes[2].animate.become(label("0", 30, GREEN, BOLD).move_to(bad_outcomes[2])),
            outcome_note.animate.become(label("0 false alerts / 0 misses", 19, GREEN, NORMAL).move_to(outcome_note)),
            run_time=1.2,
        )

        callout = label("Changing preprocessing changes the data the model learns from.", 27, INK)
        callout.to_edge(DOWN)
        self.play(FadeOut(steps))
        self.play(Write(callout))
        self.wait(1.2)

    def _plot_panel(self, text: str, shift: Mobject) -> VGroup:
        panel = RoundedRectangle(width=11.0, height=4.6, corner_radius=0.08)
        panel.set_fill(PANEL, opacity=1)
        panel.set_stroke("#FFFFFF", opacity=0.16)
        panel.shift(shift + DOWN * 0.55)
        title = label(text, 26, INK).move_to(panel.get_top() + DOWN * 0.4)
        frame = Rectangle(width=9.7, height=3.15).move_to(panel.get_center() + DOWN * 0.22)
        frame.set_stroke("#FFFFFF", opacity=0.25)
        return VGroup(panel, title, frame)

    def _plot_point(self, x: float, y: float) -> np.ndarray:
        return LEFT * 4.85 + RIGHT * x * 9.7 + DOWN * 1.7 + UP * y * 3.15

    def _point(self, x: float, y: float, color: str, issue: str = "clean") -> Mobject:
        pos = self._plot_point(x, y)
        if issue == "variant":
            marker = Square(side_length=0.18, color=PURPLE)
            marker.set_fill(color, opacity=0.95)
            marker.set_stroke(PURPLE, width=3)
            marker.rotate(PI / 4)
            marker.move_to(pos)
            return marker
        dot = Dot(pos, radius=0.075, color=color)
        dot.set_stroke("#FFFFFF", opacity=0.75, width=1)
        if issue == "duplicate":
            ring = Circle(radius=0.14, color=GOLD, stroke_width=3).move_to(pos)
            return VGroup(dot, ring)
        if issue == "wrong":
            ring = Circle(radius=0.14, color=ORANGE, stroke_width=3).move_to(pos)
            slash = Line(pos + DL * 0.08, pos + UR * 0.08, color=ORANGE, stroke_width=3)
            return VGroup(dot, ring, slash)
        return dot

    def _boundary(self, color: str, slope: float, intercept: float) -> Line:
        x1, x2 = 0.02, 0.98
        y1 = max(0.03, min(0.97, slope * x1 + intercept))
        y2 = max(0.03, min(0.97, slope * x2 + intercept))
        return Line(self._plot_point(x1, y1), self._plot_point(x2, y2), color=color, stroke_width=5)


class DiffusionScene(Scene):
    def construct(self):
        self.camera.background_color = BG
        title = label("Diffusion Lab", 40, INK).to_edge(UP)
        prompt = label("prompt: a simple smiling face icon", 25, GREEN).next_to(title, DOWN, buff=0.35)
        controls = VGroup(
            token_box("Target: Smiley", BLUE, 2.05),
            token_box("Random On", GOLD, 1.65),
            token_box("Field On", GREEN, 1.45),
            token_box("Walk On", PURPLE, 1.35),
        ).arrange(RIGHT, buff=0.14).scale(0.72)
        controls.next_to(prompt, DOWN, buff=0.18).shift(LEFT * 1.35)
        self.play(Write(title), FadeIn(prompt), FadeIn(controls))

        n = 32
        noise_rng = deterministic_random(7)
        noise_values = [noise_rng() for _ in range(n * n)]
        target_values = [
            target_intensity((i + 0.5) / n, (j + 0.5) / n)
            for j in range(n)
            for i in range(n)
        ]
        cell_size = 0.105
        image_origin = LEFT * 5.25 + UP * 1.35
        image_frame = RoundedRectangle(
            width=n * cell_size + 0.25,
            height=n * cell_size + 0.25,
            corner_radius=0.08,
        )
        image_frame.set_fill(PANEL, opacity=1)
        image_frame.set_stroke("#FFFFFF", opacity=0.16)
        image_frame.move_to(image_origin + RIGHT * (n - 1) * cell_size / 2 + DOWN * (n - 1) * cell_size / 2)
        cells = VGroup()
        for j in range(n):
            for i in range(n):
                idx = j * n + i
                sq = Square(side_length=cell_size)
                sq.set_stroke(BG, width=0.15)
                sq.set_fill(diffusion_color(noise_values[idx], target_values[idx], 0), opacity=1)
                sq.move_to(image_origin + RIGHT * i * cell_size + DOWN * j * cell_size)
                cells.add(sq)
        image_label = label("generated image", 22, MUTED, BOLD).next_to(image_frame, DOWN, buff=0.22)

        field_side = n * cell_size + 0.25
        field_frame = RoundedRectangle(width=field_side, height=field_side, corner_radius=0.08)
        field_frame.set_fill(PANEL, opacity=1)
        field_frame.set_stroke("#FFFFFF", opacity=0.16)
        field_frame.to_edge(RIGHT).shift(LEFT * 0.75 + DOWN * 0.08)
        field_title = label("random walk + vector field", 28, INK).next_to(field_frame, UP, buff=0.22)
        field_inner = field_side - 0.35

        def field_point(x: float, y: float) -> np.ndarray:
            return field_frame.get_center() + LEFT * (0.5 - x) * field_inner + UP * (0.5 - y) * field_inner

        def field_vector_for_step(x: float, y: float, step: int) -> tuple[float, float, float]:
            field_step = max(0, min(demo_steps - 1, step))
            total = 0.0
            weighted_x = 0.0
            weighted_y = 0.0
            for particle in particles:
                random_segments = particle["random_segments"]
                vector_states = particle["vector_states"]
                assert isinstance(random_segments, list)
                assert isinstance(vector_states, list)
                segment = random_segments[field_step]
                vector_state = vector_states[field_step]
                source_x = float(segment["to_x"])
                source_y = float(segment["to_y"])
                move_x = float(vector_state["x"]) - source_x
                move_y = float(vector_state["y"]) - source_y
                dx = source_x - x
                dy = source_y - y
                weight = math.exp(-(dx * dx + dy * dy) * 92) + 0.00008
                weighted_x += move_x * weight
                weighted_y += move_y * weight
                total += weight
            avg_x = weighted_x / (total or 1)
            avg_y = weighted_y / (total or 1)
            magnitude = math.hypot(avg_x, avg_y)
            if magnitude < 0.0001:
                vx, vy = learned_vector(x, y, (field_step + 1) / demo_steps, None, n, True)
                return vx, vy, 0.45
            return avg_x / magnitude, avg_y / magnitude, min(1, max(0.35, magnitude / 0.08))

        def generic_field_vector(x: float, y: float) -> tuple[float, float, float]:
            vx, vy = learned_vector(x, y, 0, None, n, True)
            return vx, vy, 0.5

        def field_arrows_for(step: int | None = None) -> VGroup:
            arrows = VGroup()
            cols = 13
            rows = 13
            for row in range(rows):
                for col in range(cols):
                    x = (col + 0.5) / cols
                    y = (row + 0.5) / rows
                    vx, vy, strength = generic_field_vector(x, y) if step is None else field_vector_for_step(x, y, step)
                    length = 0.036 + strength * 0.045
                    start = field_point(x - vx * length * 0.45, y - vy * length * 0.45)
                    end = field_point(x + vx * length * 0.55, y + vy * length * 0.55)
                    arrow = Arrow(
                        start,
                        end,
                        buff=0,
                        color=GREEN,
                        stroke_width=3,
                        max_tip_length_to_length_ratio=0.22,
                    )
                    arrow.set_opacity(0.42)
                    arrows.add(arrow)
            return arrows

        demo_steps = 10
        particles = diffusion_particles(n, True, demo_steps)
        final_dots = VGroup()
        particle_dots = VGroup()
        field_arrows = field_arrows_for(None)
        random_history = VGroup()

        for particle in particles:
            target = particle["target"]
            final = Dot(
                field_point(float(target["x"]), float(target["y"])),
                radius=0.018,
                color=str(target["color"]),
            )
            final.set_opacity(0.22)
            final_dots.add(final)

            states = particle["states"]
            assert isinstance(states, list)
            start = states[0]
            dot = Dot(field_point(float(start["x"]), float(start["y"])), radius=0.036, color=GREEN)
            particle_dots.add(dot)

        def random_segments_for(step: int, opacity: float) -> VGroup:
            segments = VGroup()
            for particle in particles:
                random_segments = particle["random_segments"]
                assert isinstance(random_segments, list)
                segment = random_segments[step]
                if float(segment["distance"]) < 0.002:
                    continue
                line = Line(
                    field_point(float(segment["from_x"]), float(segment["from_y"])),
                    field_point(float(segment["to_x"]), float(segment["to_y"])),
                    color=GOLD,
                    stroke_width=2,
                )
                line.set_opacity(opacity)
                segments.add(line)
            return segments

        def live_random_segments_for(step: int) -> VGroup:
            segments = VGroup()
            for particle, dot in zip(particles, particle_dots):
                random_segments = particle["random_segments"]
                assert isinstance(random_segments, list)
                segment = random_segments[step]
                if float(segment["distance"]) < 0.002:
                    continue
                start = field_point(float(segment["from_x"]), float(segment["from_y"]))

                def moving_line(start=start, dot=dot) -> Line:
                    line = Line(start, dot.get_center(), color=GOLD, stroke_width=2)
                    line.set_opacity(0.68)
                    return line

                segments.add(always_redraw(moving_line))
            return segments

        legend = VGroup(
            token_box("random walk", GOLD, 2.25),
            token_box("learned field", GREEN, 2.45),
        ).arrange(RIGHT, buff=0.25)
        legend.next_to(field_frame, DOWN, buff=0.25)
        step_status = label("step 0: initial random pixels", 22, GOLD).next_to(legend, DOWN, buff=0.2)

        def set_status(text: str) -> None:
            step_status.become(label(text, 22, GOLD).move_to(step_status))
            self.add(step_status)

        self.play(FadeIn(image_frame), FadeIn(cells), FadeIn(image_label), FadeIn(field_frame), FadeIn(field_title))
        self.play(FadeIn(field_arrows), FadeIn(final_dots), FadeIn(particle_dots), FadeIn(legend), FadeIn(step_status), run_time=1.0)
        self.wait(0.45)

        for step in range(demo_steps):
            progress = (step + 1) / demo_steps
            random_anims = []
            for dot, particle in zip(particle_dots, particles):
                random_segments = particle["random_segments"]
                assert isinstance(random_segments, list)
                pos = random_segments[step]
                random_anims.append(dot.animate.move_to(field_point(float(pos["to_x"]), float(pos["to_y"]))))
            set_status(f"step {step + 1}: random nudge")
            live_segments = live_random_segments_for(step)
            self.add(live_segments)
            self.play(*random_anims, run_time=0.28)
            self.remove(live_segments)
            current_segments = random_segments_for(step, 0.62)
            self.add(current_segments)
            random_history.add(current_segments)
            self.add(random_history)

            cell_anims = [
                cells[idx].animate.set_fill(diffusion_color(noise_values[idx], target_values[idx], progress), opacity=1)
                for idx in range(n * n)
            ]
            set_status(f"step {step + 1}: field update")
            self.play(
                Transform(field_arrows, field_arrows_for(step)),
                current_segments.animate.set_opacity(0.07),
                run_time=0.42,
            )
            vector_anims = []
            for dot, particle in zip(particle_dots, particles):
                vector_states = particle["vector_states"]
                assert isinstance(vector_states, list)
                pos = vector_states[step]
                vector_anims.append(dot.animate.move_to(field_point(float(pos["x"]), float(pos["y"]))))
            set_status(f"step {step + 1}: vector pull")
            self.play(*vector_anims, *cell_anims, run_time=0.35)
        self.play(random_history.animate.set_opacity(0.045), run_time=0.3)

        lock_values = [
            lock_intensity((i + 0.5) / n, (j + 0.5) / n)
            for j in range(n)
            for i in range(n)
        ]
        lock_cell_anims = [
            cells[idx].animate.set_fill(diffusion_color(noise_values[idx], lock_values[idx], 1), opacity=1)
            for idx in range(n * n)
        ]
        lock_prompt = label("prompt: a simple secure lock icon", 25, GREEN).move_to(prompt)
        lock_target = token_box("Target: Lock", BLUE, 1.85).scale(0.72).move_to(controls[0])
        set_status("target selector: lock")
        self.play(FadeOut(prompt), FadeOut(controls[0]), run_time=0.24)
        self.play(
            FadeIn(lock_prompt),
            FadeIn(lock_target),
            *lock_cell_anims,
            run_time=0.85,
        )
        self.wait(1.0)


class RewardHackingScene(Scene):
    def construct(self):
        self.camera.background_color = BG
        title = label("Reward Hacking Lab", 38, INK).to_edge(UP)
        mode_tabs = VGroup(
            token_box("Intended", BLUE, 1.45),
            token_box("Unintended", GOLD, 1.75),
        ).arrange(RIGHT, buff=0.16).scale(0.78)
        mode_tabs.next_to(title, DOWN, buff=0.26)
        mode_tabs[1].set_opacity(0.45)
        self.play(Write(title), FadeIn(mode_tabs))

        grid = VGroup()
        cells = {}
        size = 0.72
        gap = 0.08
        origin = LEFT * 4.65 + UP * 1.28
        for r in range(4):
            for c in range(4):
                cell = RoundedRectangle(width=size, height=size, corner_radius=0.05)
                cell.set_fill(PANEL, opacity=1)
                cell.set_stroke("#FFFFFF", opacity=0.12)
                cell.move_to(origin + RIGHT * c * (size + gap) + DOWN * r * (size + gap))
                cells[(c, r)] = cell
                grid.add(cell)

        cells[(1, 2)].set_fill("#f3c969", opacity=0.20)
        cells[(1, 2)].set_stroke(GOLD, width=2)
        cells[(3, 0)].set_fill("#58a6ff", opacity=0.20)
        cells[(3, 0)].set_stroke(BLUE, width=2)
        markers = VGroup(
            label("START", 14, MUTED, BOLD).move_to(cells[(0, 3)]),
            VGroup(label("CHECK", 13, GOLD, BOLD), label("+6", 16, GOLD, BOLD)).arrange(DOWN, buff=0.02).move_to(cells[(1, 2)]),
            VGroup(label("EXIT", 13, BLUE, BOLD), label("+10", 16, BLUE, BOLD)).arrange(DOWN, buff=0.02).move_to(cells[(3, 0)]),
        )
        self.play(FadeIn(grid), FadeIn(markers))

        score = metric_card("reward score", "0", BLUE).scale(0.86).to_edge(RIGHT).shift(UP * 0.95)
        mode_title = label("Intended path", 27, BLUE).next_to(score, DOWN, buff=0.42)
        note = wrapped_label("Reward matches the task: visit the checkpoint, then exit.", 21, MUTED, NORMAL, width=31)
        note.next_to(mode_title, DOWN, buff=0.22)
        self.play(FadeIn(score), FadeIn(mode_title), FadeIn(note))

        agent = Dot(radius=0.16, color=PURPLE).move_to(cells[(0, 3)])
        self.play(FadeIn(agent))
        current_trail = VGroup()

        def play_path(path: list[tuple[int, int]], rewards: list[int], color: str) -> VGroup:
            trail = VGroup()
            current_score = 0
            score[2].become(label("0", 30, color, BOLD).move_to(score[2]))
            agent.move_to(cells[path[0]])
            for index in range(1, len(path)):
                start = cells[path[index - 1]].get_center()
                end = cells[path[index]].get_center()
                segment = Line(start, end, color=color, stroke_width=5)
                segment.set_opacity(0.72)
                reward = rewards[index]
                self.play(Create(segment), agent.animate.move_to(end), run_time=0.32)
                trail.add(segment)
                self.add(trail, agent, markers)
                if reward:
                    current_score += reward
                    pulse = label(f"+{reward} reward", 19, color, BOLD).next_to(cells[path[index]], UP, buff=0.12)
                    self.play(
                        FadeIn(pulse, shift=UP * 0.12),
                        score[2].animate.become(label(str(current_score), 30, color, BOLD).move_to(score[2])),
                        run_time=0.22,
                    )
                    self.play(FadeOut(pulse), run_time=0.16)
            self.wait(0.45)
            return trail

        intended_path = [(0, 3), (0, 2), (1, 2), (2, 2), (2, 1), (3, 1), (3, 0)]
        intended_rewards = [0, 0, 6, 0, 0, 0, 10]
        current_trail = play_path(intended_path, intended_rewards, BLUE)

        farm_note = wrapped_label(
            "The agent discovers the reward can be collected again before exiting.",
            21,
            MUTED,
            NORMAL,
            width=31,
        )
        farm_note.move_to(note)
        self.play(
            FadeOut(current_trail),
            agent.animate.move_to(cells[(0, 3)]),
            mode_tabs[0].animate.set_opacity(0.45),
            mode_tabs[1].animate.set_opacity(1),
            mode_title.animate.become(label("Unintended farming", 27, GOLD).move_to(mode_title)),
            note.animate.become(farm_note),
            score[2].animate.become(label("0", 30, GOLD, BOLD).move_to(score[2])),
            run_time=0.7,
        )

        farm_path = [(0, 3), (0, 2), (1, 2), (2, 2), (1, 2), (0, 2), (1, 2)]
        farm_rewards = [0, 0, 6, 0, 6, 0, 6]
        current_trail = play_path(farm_path, farm_rewards, GOLD)

        callout = wrapped_label("The metric is technically optimized, but the objective is not what we meant.", 24, INK, NORMAL, width=54)
        callout.to_edge(DOWN)
        self.play(FadeIn(callout))
        self.wait(0.8)
